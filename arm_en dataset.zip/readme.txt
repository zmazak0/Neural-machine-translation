The dataset is based on news pages from the site news.am.
The dataset contains 19888 sentences in Armenian with English translation,
all words in lowercase.
The lines are sorted by the length of the sentences in Armenian.
The lines are represented as: 
"source'/t'target'/n'"

The archive contains the following files:
1) arm_en_dataset.(csv/txt) - 19888 arm sentences with translation.
2) arm_sentences.csv - text from 10,000+ pages from the site news.am without translation.
3) folder "parts" - 40 csv files with 400-500 translated sentences.

Dataset prepared by Martirosyan Zaven martirosian.z@mail.ru